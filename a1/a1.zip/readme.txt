Name: Ryan Kim
ID: 200390560
Email: kimx0560@mylaurier.ca
WorkID: cp411-a1
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Question_ID [self-evaluation/total/marker-evaluation] Description

A1

Q1 Concepts of raster graphics
Q1.1 [2/2/*] frame buffer                            
Q1.2 [2/2/*] pixel                                   
Q1.3 [2/2/*] color depth                             
Q1.4 [2/2/*] resolution                              
Q2 Concepts of raster display
Q2.1 [2/2/*] scan line                               
Q2.2 [2/2/*] refreshment & refresh rate              
Q2.3 [2/2/*] frame                                   
Q3 Roles of CPU and GPU in CG
Q3.1 [3/3/*] CPU roles                               
Q3.2 [3/3/*] GPU roles                               
Q4 C/C++ OpenGL programming environment
Q4.1 [4/4/*] C/C++ OpenGL installation               
Q4.2 [3/3/*] OpenGL C project                        
Q4.3 [3/3/*] OpenGL C++ project                      

Total: [0/30/*]